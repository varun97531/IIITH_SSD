import requests
import json

req_body = request.get_json()
def signin():
    email = input("Enter username: ")
    password= input("Enter password: ")

    payload = {
        "email": email,
        "password": password
    }

    resp = requests.post("http://127.0.0.1:5000/do_signin", json-payload).content.decode()
    print(resp)

def signup():
    username= input("Enter username: ")
    email = input("Enter username: ")
    password= input("Enter password: ")

    payload = {
        "username": username,
        "email": email,
        "password": password
    }

    resp = requests.post("http://127.0.0.1:5000/do_signup", json-payload).content.decode()
    print(resp)

def signout():
    resp = requests.post("http://127.0.0.1:5000/do_signup", json-payload).content.decode()
    print(resp)

while True:
    option = input("Select Values : \n1. Signup User\n2. Signin user\n3. Signout User\n")
    if(option == "1"):
        signup()
    elif(option == "2"):
        signin()
    elif(option == "3"):
        signout()
