import sqlite3

connect = sqlite3.connect('database.db')

print("opened")
connect.execute('CREATE TABLE IF NOT EXISTS USER(email TEXT, password TEXT, name TEXT)')

print("Created successfully")
connect.close()